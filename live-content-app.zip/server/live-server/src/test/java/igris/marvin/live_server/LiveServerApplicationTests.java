package igris.marvin.live_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
